library(testthat)
library(apaTables)

test_check("apaTables")
