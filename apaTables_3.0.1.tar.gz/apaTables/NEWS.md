# apaTable 3.0

## New features

* Support for latex tables via the new command apa.knit.table.for.pdf()
